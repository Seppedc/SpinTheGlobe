# Toy pin launcher

Goal: Not a firearm: playful pin-launch mechanism.

Run: `blender --background --python "Assets/DetectiveDesk/ArtSource/Gameplay/PinLauncher/build_asset.py"` from Unity project root.

Outputs: PinLauncher.blend (editable Blender source with embedded generator); PinLauncher.fbx (if Blender FBX exporter succeeds).

This is a structured procedural **starter**, not a reference-matched high-detail model. For final quality: refine the geometry/materials in this source script, regenerate, then check Game camera in Unity.

See References/ for inspiration, and do not modify existing Unity prefabs or their scripts without a backup.
