# Whiskey bottle

Clear glass bottle/decanter, stopper, no branded labels

Primary look: straight-on seated noir detective hub, dark mahogany, aged brass, deep burgundy, green banker lamp, cool rainy window.

Use images in this folder as VISUAL REFERENCES ONLY, not as meshes. Never place photographs as hidden layers on the geographic map.
