param([Parameter(Mandatory=$true)][string]$Slug,[string]$Blender="blender")
$Root=Split-Path -Parent $PSScriptRoot
$Matches=@(Get-ChildItem (Join-Path $Root "Assets/DetectiveDesk/ArtSource") -Recurse -Filter build_asset.py | Where-Object { (Split-Path (Split-Path $_.FullName -Parent) -Leaf) -eq $Slug })
if ($Matches.Count -ne 1) { throw "Expected one build_asset.py for '$Slug'; found $($Matches.Count). Check spelling or choose a Blender-backed group." }
& $Blender --background --python $Matches[0].FullName
if ($LASTEXITCODE -ne 0) { throw "Blender build failed ($LASTEXITCODE)" }
Write-Output "Built $Slug. Check .blend and .fbx in $($Matches[0].DirectoryName)"
